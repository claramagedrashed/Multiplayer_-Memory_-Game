#include "display.h"
#include <LiquidCrystal_I2C.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>

static LiquidCrystal_I2C lcd(LCD_I2C_ADDR, LCD_COLS, LCD_ROWS);

void display_init(void)
{
    lcd.init();
    lcd.backlight();
    lcd.clear();
}

void display_clear(void)
{
    lcd.clear();
}

void display_backlight(bool on)
{
    if (on) lcd.backlight();
    else    lcd.noBacklight();
}

void display_print(uint8_t row, const char *text)
{
    char buf[LCD_COLS + 1];
    memset(buf, ' ', LCD_COLS);
    buf[LCD_COLS] = '\0';
    uint8_t len = (uint8_t)strlen(text);
    if (len > LCD_COLS) len = LCD_COLS;
    memcpy(buf, text, len);
    lcd.setCursor(0, row);
    lcd.print(buf);
}

void display_print2(const char *row0, const char *row1)
{
    display_print(0, row0);
    display_print(1, row1);
}

void display_printf(uint8_t row, const char *fmt, ...)
{
    char buf[LCD_COLS + 1];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    display_print(row, buf);
}

void display_scores(uint8_t p1, uint8_t p2)
{
    char buf[LCD_COLS + 1];
    snprintf(buf, sizeof(buf), "P1:%-4u  P2:%-4u", p1, p2);
    display_print(0, buf);
}

void display_solo_score(uint16_t score)
{
    char buf[LCD_COLS + 1];
    snprintf(buf, sizeof(buf), "Score: %u", score);
    display_print(0, buf);
}

void display_countdown(uint8_t n)
{
    char buf[LCD_COLS + 1];
    snprintf(buf, sizeof(buf), "    %u    ", n);
    display_print(1, buf);
}