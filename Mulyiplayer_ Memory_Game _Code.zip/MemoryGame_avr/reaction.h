#ifndef REACTION_H
#define REACTION_H

#include <Arduino.h>
#include "states.h"
#include "eeprom_manager.h"

void reaction_init(void);
GameState reaction_update(PlayerStats *stats);

#endif // REACTION_H
