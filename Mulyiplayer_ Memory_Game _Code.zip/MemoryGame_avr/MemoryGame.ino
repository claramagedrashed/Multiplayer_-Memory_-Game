/*
 * MemoryGame.ino
 * Arduino Uno / ATmega328P @ 16 MHz
 *
 * Multiplayer memory/reaction game system.
 * Top-level finite state machine.
 */

#include "config.h"
#include "states.h"
#include "timer.h"
#include "gpio.h"
#include "display.h"
#include "audio.h"
#include "rng.h"
#include "eeprom_manager.h"
#include "sleep_manager.h"
#include "menu.h"
#include "solo.h"
#include "duo.h"
#include "reaction.h"
#include "challenger.h"

static GameState   g_state = STATE_MENU;
static PlayerStats g_stats;

// Show persisted stats screen and wait for user acknowledgement.
static void show_stats(void)
{
    char buf0[17], buf1[17];
    snprintf(buf0, sizeof(buf0), "P1W:%u P2W:%u",
             g_stats.p1_wins, g_stats.p2_wins);
    snprintf(buf1, sizeof(buf1), "Best:%u Tot:%u",
             g_stats.best_solo_score, g_stats.total_games);
    display_print2(buf0, buf1);
    timer_delay_ms(3000);
    while (!any_button_pressed()) {}
    wait_all_released();
}

static void do_eeprom_reset(void)
{
    display_print2("Reset EEPROM?", "SEL=Yes BACK=No");
    while (true) {
        if (btn_select_pressed()) {
            wait_all_released();
            eeprom_reset(&g_stats);
            display_print2("EEPROM Reset!", "Done.");
            audio_win();
            timer_delay_ms(1500);
            break;
        }
        if (btn_back_pressed()) {
            wait_all_released();
            display_print2("Cancelled.", "");
            timer_delay_ms(800);
            break;
        }
    }
}

void setup(void)
{
    // Initialize low-level services first so higher-level modules can use them.
    timer_init();
    gpio_init();
    display_init();
    audio_init();
    rng_init();
    eeprom_init();
    eeprom_load(&g_stats);
    sleep_reset_timer();
    audio_startup();

    // Short splash sequence.
    display_print2("Welcome to", "Seq Game");
    timer_delay_ms(2000);

    display_print2("Made by", "Team 24");
    timer_delay_ms(2000);

    display_print2(" Memory Game ", "  Starting...  ");
    timer_delay_ms(1200);

    menu_init();
    g_state = STATE_MENU;
}

void loop(void)
{
    // Sleep management only runs while browsing menu.
    if (g_state == STATE_MENU) {
        if (sleep_manager_update()) {
            sleep_reset_timer();   // reset so next game's timeouts start clean
            menu_redraw();
            return;
        }
    }

    switch (g_state)
    {
        case STATE_MENU:
        {
            // Menu decides whether we stay in menu or start a mode.
            GameState next = menu_update();
            if (next != STATE_MENU) {
                sleep_reset_timer();
                g_state = next;
                // One-time per-entry initialization for each mode.
                switch (g_state) {
                    case STATE_SOLO:       solo_init();       break;
                    case STATE_DUO:        duo_init();        break;
                    case STATE_REACTION:   reaction_init();   break;
                    case STATE_CHALLENGER: challenger_init(); break;
                    default: break;
                }
            }
            break;
        }

        case STATE_SOLO:
        {
            // Mode update returns STATE_MENU when game round/session ends.
            GameState next = solo_update(&g_stats);
            if (next == STATE_MENU) {
                g_state = STATE_MENU;
                menu_redraw();
            }
            break;
        }

        case STATE_DUO:
        {
            GameState next = duo_update(&g_stats);
            if (next == STATE_MENU) {
                g_state = STATE_MENU;
                menu_redraw();
            }
            break;
        }

        case STATE_REACTION:
        {
            GameState next = reaction_update(&g_stats);
            if (next == STATE_MENU) {
                g_state = STATE_MENU;
                menu_redraw();
            }
            break;
        }

        case STATE_CHALLENGER:
        {
            GameState next = challenger_update(&g_stats);
            if (next == STATE_MENU) {
                g_state = STATE_MENU;
                menu_redraw();
            }
            break;
        }

        case STATE_STATS:
        {
            // Read-only stats page from EEPROM-backed counters.
            show_stats();
            g_state = STATE_MENU;
            menu_redraw();
            break;
        }

        case STATE_RESET_EEPROM:
        {
            // Destructive operation is gated behind explicit confirmation.
            do_eeprom_reset();
            g_state = STATE_MENU;
            menu_redraw();
            break;
        }

        case STATE_SLEEP:
        {
            // Optional direct sleep state (most sleep flow is menu-driven).
            sleep_enter();
            g_state = STATE_MENU;
            menu_redraw();
            break;
        }
    }
}
