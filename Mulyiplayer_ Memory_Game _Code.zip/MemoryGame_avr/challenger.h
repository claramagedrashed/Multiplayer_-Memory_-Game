#ifndef CHALLENGER_H
#define CHALLENGER_H

#include <Arduino.h>
#include "states.h"
#include "eeprom_manager.h"

void challenger_init(void);
GameState challenger_update(PlayerStats *stats);

#endif // CHALLENGER_H
