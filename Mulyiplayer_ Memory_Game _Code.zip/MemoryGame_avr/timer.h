#ifndef TIMER_H
#define TIMER_H

#include <Arduino.h>
#include "config.h"

// Configure Timer1 in CTC mode to generate a 1 ms system tick interrupt.
void     timer_init(void);
// Return elapsed milliseconds since boot.
uint32_t timer_millis(void);
// Blocking delay based on timer_millis().
void     timer_delay_ms(uint32_t ms);

#endif // TIMER_H