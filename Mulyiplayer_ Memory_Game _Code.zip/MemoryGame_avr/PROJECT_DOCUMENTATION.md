# Memory Game AVR - Full Code Documentation

This document explains the full project structure, hardware mapping, software architecture, and how each file/module works.

## 1) Project Overview

This is an Arduino Uno (`ATmega328P @ 16 MHz`) memory/reaction game platform with:

- 4 LEDs for sequence display
- 8 gameplay buttons (4 per player)
- 3 menu buttons (Menu / Select / Back)
- 16x2 I2C LCD
- Piezo buzzer
- EEPROM-backed persistent stats
- Automatic low-power sleep from menu inactivity

The software is split into small modules:

- one central finite state machine (FSM) in `MemoryGame.ino`
- one module per game mode (`solo`, `duo`, `reaction`, `challenger`)
- shared utility modules for GPIO, timer, display, audio, RNG, sleep, and EEPROM

---

## 2) Hardware Pin Allocation

Pin mapping from `config.h` and `gpio.cpp`:

- **LED outputs**
  - `LED1_PIN` = D2
  - `LED2_PIN` = D3
  - `LED3_PIN` = D4
  - `LED4_PIN` = D5

- **Player 1 buttons (active LOW, pull-up enabled)**
  - `P1_B1_PIN` = D8
  - `P1_B2_PIN` = D9
  - `P1_B3_PIN` = D10
  - `P1_B4_PIN` = D11

- **Buzzer**
  - `BUZZER_PIN` = D12

- **Player 2 buttons**
  - `P2_B1_PIN` = D6
  - `P2_B2_PIN` = D7
  - `P2_B3_PIN` = D13
  - `P2_B4_PIN` = A3

- **Menu buttons**
  - `MENU_BTN_PIN` = A0
  - `SELECT_BTN_PIN` = A1
  - `BACK_BTN_PIN` = A2

- **LCD I2C**
  - Address `0x27`, `16x2` characters

Electrical logic is mostly `INPUT_PULLUP`, so:

- **Pressed button = LOW**
- **Released button = HIGH**

---

## 3) Core Constants and Tunables (`config.h`)

Main gameplay/system constants:

- `MAX_SEQUENCE = 64`
- `WIN_SCORE = 3`
- Solo timings:
  - `SOLO_INIT_DISPLAY_MS = 500`
  - `SOLO_TIMEOUT_MS = 5000`
  - `SOLO_MIN_SPEED_MS = 200`
  - `SOLO_SPEED_STEP_MS = 20`
- Reaction timings:
  - `REACTION_MIN_DELAY_MS = 2000`
  - `REACTION_MAX_DELAY_MS = 5000`
  - `REACTION_TIMEOUT_MS = 5000`
- Challenger inactivity auto-submit:
  - `CHALLENGER_INACTIVITY_MS = 2000`
- Sleep policy:
  - `SLEEP_INACTIVITY_MS = 60000`
  - `SLEEP_COUNTDOWN_SEC = 5`
- Debounce:
  - `DEBOUNCE_MS = 25`

If you want to retune game difficulty/speed, this file is the first place to edit.

---

## 4) Top-Level Architecture and FSM

### `states.h`

Defines:

- top-level `GameState` (`STATE_MENU`, `STATE_SOLO`, etc.)
- sub-state enums per mode:
  - `SoloSubState`
  - `DuoSubState`
  - `ReactionSubState`
  - `ChallengerSubState`
- `MenuItem` enum for menu entries

### `MemoryGame.ino` (main orchestrator)

Responsibilities:

- Initialize all modules in `setup()`
- Show startup screens and startup sound
- Keep global current state (`g_state`) and persistent stats (`g_stats`)
- In `loop()`, dispatch control to active state:
  - menu
  - selected game mode
  - stats screen
  - EEPROM reset flow
  - sleep handling

Flow pattern:

1. State update function returns next state or same state.
2. On transitions back to menu, `menu_redraw()` is called.
3. Mode init functions (`solo_init()`, etc.) are called when entering a game mode.

---

## 5) File-by-File Explanation

### `MemoryGame.ino`

- Entry point.
- Boot sequence, module initialization, global FSM, mode dispatch.
- Handles the non-game menu actions:
  - show stats
  - reset EEPROM

### `config.h`

- Central hardware pin macros and global constants.
- Keeps timing and behavior tuning in one place.

### `states.h`

- Shared enums for all game and menu states.

### `gpio.h` / `gpio.cpp`

Hardware I/O layer with direct AVR register access for speed:

- Configures all pins in `gpio_init()`
- LED functions:
  - `led_set`, `led_all_on`, `led_all_off`
- Debounced input API:
  - `p1_buttons_read()`, `p2_buttons_read()`
  - `btn_menu_pressed()`, `btn_select_pressed()`, `btn_back_pressed()`
- Raw input helpers:
  - `back_pressed_raw()` for immediate exits
  - `any_button_pressed()` for wake/continue prompts
- Debounce controls:
  - `debounce_flush()` resets timestamp history
- Synchronization:
  - `wait_all_released()` blocks until all keys are released

Design note:

- Debounce is timestamp-based. This avoids noisy edges being interpreted as multiple presses.

### `timer.h` / `timer.cpp`

System clock/timing layer:

- Configures **Timer1 CTC interrupt** at 1ms tick
- `timer_millis()` provides monotonic milliseconds
- `timer_delay_ms()` performs blocking delays using that counter

This is the timing foundation for all mode logic and debouncing.

### `display.h` / `display.cpp`

LCD abstraction (`LiquidCrystal_I2C`):

- Init/clear/backlight control
- Safe row print helper (`display_print`) that pads/truncates to 16 chars
- Convenience helpers:
  - `display_print2`
  - `display_printf`
  - `display_scores`
  - `display_solo_score`
  - `display_countdown`

### `audio.h` / `audio.cpp`

Buzzer abstraction:

- Uses Arduino `tone()` / `noTone()` (Timer2 ownership stays with Arduino core)
- Common sounds:
  - startup melody
  - menu click
  - correct beep
  - win melody
  - fail melody

### `rng.h` / `rng.cpp`

Randomness utilities:

- Seeds from ADC noise (`analogRead(A5)`) plus LCG mixing
- Helpers:
  - `rng_range(max)`
  - `rng_next_led(last_led)` to avoid repeated same LED
  - `rng_range32(lo, hi)` for reaction delays

### `eeprom_manager.h` / `eeprom_manager.cpp`

Persistent player stats:

- `PlayerStats` contains:
  - `p1_wins`, `p2_wins`
  - `best_solo_score`
  - `total_games`
  - `checksum`
- `eeprom_load()` validates checksum
- Corrupt/first-boot data auto-resets
- `eeprom_save()` writes with recomputed checksum
- `eeprom_init()` includes `static_assert` for struct layout safety

### `sleep_manager.h` / `sleep_manager.cpp`

Menu inactivity power management:

- Tracks last activity time
- `sleep_manager_update()` triggers sleep countdown in menu only
- Cancel sleep if any button press during countdown
- `sleep_enter()`:
  - LCD backlight off
  - enables pin-change interrupts (PCINT on all button groups)
  - enters `SLEEP_MODE_PWR_DOWN`
  - wakes on button press, restores display, waits release

### `menu.h` / `menu.cpp`

Menu FSM:

- Cycles entries with `MENU` button
- Chooses with `SELECT`
- Uses `audio_menu_click()`
- Calls `sleep_reset_timer()` on interactions
- Returns `GameState` selected by current menu item

### `gameplay_utils.h` / `gameplay_utils.cpp`

Shared gameplay helpers:

- `checkBackToMenu()` immediate safe exit from gameplay
- `resetGameState()` turns off LEDs/buzzer
- `failAnimation()` shared failure LED/audio pattern
- `winAnimation(player)` shared win feedback
- `delay_or_back(ms)` delay that can be interrupted by BACK

### `solo.h` / `solo.cpp`

Single-player memory mode:

- Builds growing random sequence
- Shows sequence to player
- Player repeats within timeout per step
- On success:
  - score increases
  - sequence grows
  - display speed increases gradually
- On fail:
  - game over screen
  - updates `best_solo_score` and `total_games`

Input robustness details:

- uses debounce flush at input phase boundaries
- uses release waits to avoid held-button double counting between expected steps

### `duo.h` / `duo.cpp`

Competitive memory replay mode:

- Shared random sequence shown to both players
- P1 reproduces, then P2 reproduces
- Scores awarded per round:
  - both correct -> both +1
  - one correct -> that player +1
  - none correct -> no points
- first to `WIN_SCORE` with non-tie condition wins game
- updates winner stats and `total_games`

### `reaction.h` / `reaction.cpp`

Reaction duel mode:

- Random wait period (`REACTION_MIN_DELAY_MS`..`MAX_DELAY_MS`)
- Random LED lights up
- Both players race to press matching button
- Wrong button counts as false start and awards point to opponent
- Timeout/no reaction can replay round
- Fastest valid reaction wins round
- first to `WIN_SCORE` wins game and updates stats

### `challenger.h` / `challenger.cpp`

Creator-vs-repeater mode:

- One player (creator) enters custom sequence manually
- Sequence auto-submits after inactivity
- Opponent watches playback then tries to repeat from memory
- Score goes to repeater on success, creator on fail/timeout
- Creator alternates each round
- win condition: reached `WIN_SCORE` and not tied

Implementation detail:

- This mode uses raw reads in entry/repeat phases and explicit press-release handling for deterministic behavior.

---

## 6) How a Typical Game Session Works

1. Boot initializes all modules.
2. Menu is displayed.
3. User picks mode.
4. Main FSM enters selected mode and calls that mode's `*_init()`.
5. Mode-specific update function runs every loop iteration until it returns `STATE_MENU`.
6. Menu redraws and inactivity sleep logic resumes.

---

## 7) Input Handling Model (Important)

The project mixes two input styles intentionally:

- **Debounced reads** for gameplay/menu events where one stable press event is needed.
- **Raw reads** for ultra-low-latency exits (`BACK`) and broad "press any button" checks.

Supporting helpers:

- `debounce_flush()` clears stale timestamps when transitioning between input phases.
- `wait_all_released()` enforces clean handoff between presses.

This is key to avoiding phantom double-presses and missed first presses across rounds.

---

## 8) Persistence and Stats

Stored in EEPROM:

- P1 wins
- P2 wins
- Best solo score
- Total games

Checksum policy:

- XOR over all stat bytes except checksum field
- On mismatch at load -> auto reset defaults

---

## 9) Sleep/Wake Behavior

Only active in menu state:

- 60s inactivity -> on-screen countdown
- any button during countdown cancels sleep
- if countdown completes, MCU sleeps in power-down
- any mapped button triggers wake via pin-change interrupt

Post-wake:

- backlight restored
- waits for wake button release
- returns to menu flow cleanly

---

## 10) Extend/Modify Guide

If you want to add a new mode:

1. Add new `GameState` and substate enum in `states.h`.
2. Create `newmode.h/.cpp` with `newmode_init()` and `newmode_update(PlayerStats*)`.
3. Add menu entry in `menu.cpp` and route selection to new state.
4. Hook transition in `MemoryGame.ino`:
   - call `newmode_init()` when entering
   - call `newmode_update()` in switch
5. Reuse shared helpers from `gameplay_utils`, `gpio`, `display`, `audio`.

---

## 11) Known Design Characteristics

- Most mode functions are intentionally blocking in small loops for deterministic behavior on AVR.
- Timer1 provides millisecond time base; Timer2 remains reserved by Arduino tone subsystem.
- Direct register I/O improves responsiveness over repeated `digitalRead` in critical paths.
- State machines are explicit and easy to debug per mode.

---

## 12) Quick File Index

- Core:
  - `MemoryGame.ino`, `config.h`, `states.h`
- Platform:
  - `gpio.*`, `timer.*`, `display.*`, `audio.*`, `rng.*`, `sleep_manager.*`, `eeprom_manager.*`, `gameplay_utils.*`
- Menu:
  - `menu.*`
- Modes:
  - `solo.*`, `duo.*`, `reaction.*`, `challenger.*`

---

If you want, I can also generate a second short version (`QUICK_START.md`) with only:

- wiring checklist
- compile/upload steps
- mode behavior summary
- tuning cheatsheet (which constants to edit for speed/difficulty)
