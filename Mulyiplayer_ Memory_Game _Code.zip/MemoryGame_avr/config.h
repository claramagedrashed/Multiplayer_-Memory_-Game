#ifndef CONFIG_H
#define CONFIG_H

#include <Arduino.h>

// ── LED PINS ──────────────────────────────────────────────────────────────────
#define LED1_PIN        2
#define LED2_PIN        3
#define LED3_PIN        4
#define LED4_PIN        5

// ── PLAYER 1 BUTTONS ─────────────────────────────────────────────────────────
#define P1_B1_PIN       8
#define P1_B2_PIN       9
#define P1_B3_PIN       10
#define P1_B4_PIN       11

// ── BUZZER ───────────────────────────────────────────────────────────────────
#define BUZZER_PIN      12

// ── PLAYER 2 BUTTONS ─────────────────────────────────────────────────────────
#define P2_B1_PIN       6
#define P2_B2_PIN       7
#define P2_B3_PIN       13
#define P2_B4_PIN       A3

// ── MENU BUTTONS ─────────────────────────────────────────────────────────────
#define MENU_BTN_PIN    A0
#define SELECT_BTN_PIN  A1
#define BACK_BTN_PIN    A2

// ── LCD I2C ───────────────────────────────────────────────────────────────────
#define LCD_I2C_ADDR    0x27
#define LCD_COLS        16
#define LCD_ROWS        2

// ── GAME CONSTANTS ────────────────────────────────────────────────────────────
#define MAX_SEQUENCE            64
#define NUM_LEDS                4
#define WIN_SCORE               3

// Solo / Duo timing
#define SOLO_INIT_DISPLAY_MS    500u
#define SOLO_TIMEOUT_MS         5000UL
#define SOLO_MIN_SPEED_MS       200u
#define SOLO_SPEED_STEP_MS      20u

// Reaction mode
#define REACTION_MIN_DELAY_MS   2000UL
#define REACTION_MAX_DELAY_MS   5000UL
#define REACTION_TIMEOUT_MS     5000UL

// Challenger mode
#define CHALLENGER_INACTIVITY_MS  2000UL

// Sleep – 60 second inactivity timeout
#define SLEEP_INACTIVITY_MS     60000UL
#define SLEEP_COUNTDOWN_SEC     5

// Debounce – 25 ms for crisp response
#define DEBOUNCE_MS             25

// Timer1 tick (ms)
#define TIMER_TICK_MS           1

// Automatic turn-switch pause (ms)
#define TURN_PAUSE_MS           300u

#endif // CONFIG_H