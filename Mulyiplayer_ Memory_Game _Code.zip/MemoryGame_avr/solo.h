#ifndef SOLO_H
#define SOLO_H

#include <Arduino.h>
#include "states.h"
#include "eeprom_manager.h"

void solo_init(void);

// Returns STATE_SOLO while playing, STATE_MENU when done
GameState solo_update(PlayerStats *stats);

#endif // SOLO_H
