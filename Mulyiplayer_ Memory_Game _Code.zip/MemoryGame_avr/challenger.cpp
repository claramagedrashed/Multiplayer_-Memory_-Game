#include "challenger.h"
#include "display.h"
#include "gpio.h"
#include "audio.h"
#include "timer.h"
#include "sleep_manager.h"
#include "gameplay_utils.h"
#include "eeprom_manager.h"
#include "config.h"
 
// ── Module state ──────────────────────────────────────────────────────────────
static uint8_t            g_sequence[MAX_SEQUENCE];
static uint8_t            g_seq_len  = 0;
static uint8_t            g_p1_score = 0;
static uint8_t            g_p2_score = 0;
static bool               g_a_is_p1  = true;   // who is the creator this round
static ChallengerSubState g_sub      = CHALLENGER_A_ENTERING;
 
// ── Name helpers ──────────────────────────────────────────────────────────────
static inline const char *creator_name(void)  { return g_a_is_p1 ? "P1" : "P2"; }
static inline const char *repeater_name(void) { return g_a_is_p1 ? "P2" : "P1"; }
 
// ── Raw single-pin read (no debounce state pollution) ─────────────────────────
// We use raw digitalRead inside the entry/repeat phases because we manage
// our own press-and-release cycle explicitly — this avoids the debounce
// timestamp getting consumed and blocking the very next read.
static bool raw_p1_any(void)
{
    return (digitalRead(P1_B1_PIN) == LOW ||
            digitalRead(P1_B2_PIN) == LOW ||
            digitalRead(P1_B3_PIN) == LOW ||
            digitalRead(P1_B4_PIN) == LOW);
}
 
static bool raw_p2_any(void)
{
    return (digitalRead(P2_B1_PIN) == LOW ||
            digitalRead(P2_B2_PIN) == LOW ||
            digitalRead(P2_B3_PIN) == LOW ||
            digitalRead(P2_B4_PIN) == LOW);
}
 
// Returns the index (0-3) of the first button that is currently LOW,
// or 0xFF if none are pressed.
static uint8_t raw_p1_which(void)
{
    const uint8_t pins[4] = { P1_B1_PIN, P1_B2_PIN, P1_B3_PIN, P1_B4_PIN };
    for (uint8_t i = 0; i < 4; i++)
        if (digitalRead(pins[i]) == LOW) return i;
    return 0xFF;
}
 
static uint8_t raw_p2_which(void)
{
    const uint8_t pins[4] = { P2_B1_PIN, P2_B2_PIN, P2_B3_PIN, P2_B4_PIN };
    for (uint8_t i = 0; i < 4; i++)
        if (digitalRead(pins[i]) == LOW) return i;
    return 0xFF;
}
 
// Block until all creator buttons are released
static void wait_creator_released(void)
{
    if (g_a_is_p1) { while (raw_p1_any()) {} }
    else            { while (raw_p2_any()) {} }
    timer_delay_ms(20);
}
 
// Block until all repeater buttons are released
static void wait_repeater_released(void)
{
    if (g_a_is_p1) { while (raw_p2_any()) {} }
    else            { while (raw_p1_any()) {} }
    timer_delay_ms(20);
}
 
// ─────────────────────────────────────────────────────────────────────────────
// Phase 1 – Creator enters sequence
// Returns false if BACK was pressed (caller must exit to menu).
// ─────────────────────────────────────────────────────────────────────────────
static bool do_entry_phase(void)
{
    g_seq_len = 0;
 
    char top[17];
    snprintf(top, sizeof(top), "%s: Enter Seq", creator_name());
    display_print2(top, "3s idle=submit");
 
    // Make sure no button is held from a previous state
    wait_creator_released();
 
    uint32_t last_press = timer_millis();
 
    while (true)
    {
        // BACK exits the whole game
        if (checkBackToMenu()) return false;
 
        // Auto-submit after 3 seconds of inactivity (only if at least 1 step)
        if (g_seq_len > 0 &&
            (timer_millis() - last_press) >= CHALLENGER_INACTIVITY_MS)
        {
            break;
        }
 
        // Read which button is pressed (raw, no debounce layer)
        uint8_t btn = g_a_is_p1 ? raw_p1_which() : raw_p2_which();
        if (btn == 0xFF) continue;   // nothing pressed yet
 
        // ── Button is down ────────────────────────────────────────────────────
 
        if (g_seq_len < MAX_SEQUENCE)
        {
            g_sequence[g_seq_len++] = btn;
 
            // Visual + audio feedback
            led_set(btn, HIGH);
            tone(BUZZER_PIN, 900, 60);
            timer_delay_ms(60);
            noTone(BUZZER_PIN);
            led_set(btn, LOW);
 
            last_press = timer_millis();
 
            // Update length display
            char buf[17];
            snprintf(buf, sizeof(buf), "Len: %u  (3s done)", g_seq_len);
            display_print(1, buf);
        }
 
        // Wait for this button to be fully released before accepting the next
        wait_creator_released();
    }
 
    return true;   // sequence captured (g_seq_len >= 1 guaranteed by break condition)
}
 
// ─────────────────────────────────────────────────────────────────────────────
// Phase 2 – Show creator's sequence to repeater via LEDs
// Returns false if BACK was pressed.
// ─────────────────────────────────────────────────────────────────────────────
static bool do_show_phase(void)
{
    char top[17];
    snprintf(top, sizeof(top), "%s: Watch!", repeater_name());
    display_print2(top, "Memorise...");
    timer_delay_ms(400);
 
    for (uint8_t i = 0; i < g_seq_len; i++)
    {
        if (checkBackToMenu()) return false;
 
        led_all_off();
        timer_delay_ms(60);
 
        led_set(g_sequence[i], HIGH);
        tone(BUZZER_PIN, 850, 200);
        timer_delay_ms(200);
        noTone(BUZZER_PIN);
 
        led_all_off();
        timer_delay_ms(80);
    }
 
    return true;
}
 
// ─────────────────────────────────────────────────────────────────────────────
// Phase 3 – Repeater reproduces the sequence from memory
// Returns:  1 = all correct
//           0 = wrong button or timeout
//          -1 = BACK pressed
// ─────────────────────────────────────────────────────────────────────────────
static int8_t do_repeat_phase(void)
{
    // Make sure repeater's buttons are clear before we start
    wait_repeater_released();
 
    uint8_t  idx     = 0;
    uint32_t t_start = timer_millis();
 
    while (idx < g_seq_len)
    {
        if (checkBackToMenu()) return -1;
 
        // Per-button timeout
        if ((timer_millis() - t_start) > SOLO_TIMEOUT_MS) return 0;
 
        // Raw read – we handle release ourselves
        uint8_t btn = g_a_is_p1 ? raw_p2_which() : raw_p1_which();
        if (btn == 0xFF) continue;   // nothing pressed yet
 
        // ── Button is down ────────────────────────────────────────────────────
 
        // Visual + audio echo
        led_set(btn, HIGH);
        tone(BUZZER_PIN, 1000, 60);
        timer_delay_ms(60);
        noTone(BUZZER_PIN);
        led_set(btn, LOW);
 
        // Wait for release before evaluating (prevents double-count)
        wait_repeater_released();
 
        if (btn == g_sequence[idx])
        {
            audio_correct();
            idx++;
            t_start = timer_millis();   // reset timeout after each correct press
        }
        else
        {
            return 0;   // wrong button
        }
    }
 
    return 1;   // all steps correct
}
 
// ─────────────────────────────────────────────────────────────────────────────
void challenger_init(void)
{
    g_seq_len  = 0;
    g_p1_score = 0;
    g_p2_score = 0;
    g_a_is_p1  = true;
    g_sub      = CHALLENGER_A_ENTERING;
}
 
// ─────────────────────────────────────────────────────────────────────────────
GameState challenger_update(PlayerStats *stats)
{
    if (checkBackToMenu()) { resetGameState(); return STATE_MENU; }
 
    switch (g_sub)
    {
    // ── CREATOR BUILDS SEQUENCE ───────────────────────────────────────────────
    case CHALLENGER_A_ENTERING:
    {
        if (!do_entry_phase()) { resetGameState(); return STATE_MENU; }
 
        sleep_reset_timer();
        g_sub = CHALLENGER_SHOW_TO_B;
        break;
    }
 
    // ── SHOW SEQUENCE TO REPEATER ─────────────────────────────────────────────
    case CHALLENGER_SHOW_TO_B:
    {
        if (!do_show_phase()) { resetGameState(); return STATE_MENU; }
 
        // Short pause so repeater is ready
        char rdy[17];
        snprintf(rdy, sizeof(rdy), "%s: Your turn!", repeater_name());
        display_print2(rdy, "Enter sequence");
        if (delay_or_back(600)) { resetGameState(); return STATE_MENU; }
 
        g_sub = CHALLENGER_B_REPEATING;
        break;
    }
 
    // ── REPEATER ENTERS SEQUENCE ──────────────────────────────────────────────
    case CHALLENGER_B_REPEATING:
    {
        debounce_flush();
        int8_t res = do_repeat_phase();
        if (res == -1) { resetGameState(); return STATE_MENU; }
 
        sleep_reset_timer();
 
        if (res == 1)
        {
            // Repeater correct → repeater scores
            if (g_a_is_p1) g_p2_score++;
            else            g_p1_score++;
 
            char msg[17];
            snprintf(msg, sizeof(msg), "%s +1 point!", repeater_name());
            display_print(0, "Correct!");
            display_print(1, msg);
            audio_correct();
        }
        else
        {
            // Repeater wrong/timeout → creator scores
            if (g_a_is_p1) g_p1_score++;
            else            g_p2_score++;
 
            char msg[17];
            snprintf(msg, sizeof(msg), "%s +1 point!", creator_name());
            failAnimation();
            display_print(0, "Wrong/Timeout!");
            display_print(1, msg);
        }
 
        if (delay_or_back(800)) { resetGameState(); return STATE_MENU; }
        g_sub = CHALLENGER_ROUND_RESULT;
        break;
    }
 
    // ── ROUND RESULT ──────────────────────────────────────────────────────────
    case CHALLENGER_ROUND_RESULT:
    {
        display_scores(g_p1_score, g_p2_score);
 
        // Win condition: strictly ahead after WIN_SCORE reached
        bool game_over = (g_p1_score >= WIN_SCORE || g_p2_score >= WIN_SCORE)
                         && (g_p1_score != g_p2_score);
 
        if (game_over)
        {
            display_print(1, "Game Over!");
            if (delay_or_back(600)) { resetGameState(); return STATE_MENU; }
            g_sub = CHALLENGER_GAME_OVER;
        }
        else
        {
            // Tie at WIN_SCORE → sudden death notice
            if (g_p1_score >= WIN_SCORE && g_p1_score == g_p2_score)
            {
                display_print(1, "Tie! Keep going");
                if (delay_or_back(900)) { resetGameState(); return STATE_MENU; }
            }
            else
            {
                display_print(1, "Next round...");
                if (delay_or_back(700)) { resetGameState(); return STATE_MENU; }
            }
 
            g_a_is_p1 = !g_a_is_p1;   // alternate creator
            g_sub = CHALLENGER_A_ENTERING;
        }
        break;
    }
 
    // ── GAME OVER ─────────────────────────────────────────────────────────────
    case CHALLENGER_GAME_OVER:
    {
        uint8_t winner = (g_p1_score > g_p2_score) ? 1u : 2u;
 
        if (winner == 1) stats->p1_wins++;
        else             stats->p2_wins++;
        stats->total_games++;
        eeprom_save(stats);
 
        winAnimation(winner);
        timer_delay_ms(400);
 
        wait_all_released();
        display_print2("Challenger done", "Press any btn");
        while (!any_button_pressed())
        {
            if (checkBackToMenu()) { resetGameState(); return STATE_MENU; }
        }
        wait_all_released();
        resetGameState();
        return STATE_MENU;
    }
 
    } // switch
 
    return STATE_CHALLENGER;
}
 