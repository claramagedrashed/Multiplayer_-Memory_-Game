#ifndef GAMEPLAY_UTILS_H
#define GAMEPLAY_UTILS_H

#include <Arduino.h>

// Returns true if BACK was pressed; performs hardware cleanup + waits release.
bool checkBackToMenu(void);

// Full hardware cleanup (LEDs off, buzzer off). Call before STATE_MENU return.
void resetGameState(void);

// 2x LED blink + descending fail tones. ~600 ms total.
void failAnimation(void);

// LCD winner message + rapid LED flashes + ascending melody. player = 1 or 2.
void winAnimation(uint8_t player);

// Spins for ms, returns true early if BACK pressed.
bool delay_or_back(uint32_t ms);

#endif // GAMEPLAY_UTILS_H
