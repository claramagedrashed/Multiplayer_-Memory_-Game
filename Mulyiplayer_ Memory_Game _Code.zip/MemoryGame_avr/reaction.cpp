#include "reaction.h"
#include "display.h"
#include "gpio.h"
#include "audio.h"
#include "timer.h"
#include "rng.h"
#include "sleep_manager.h"
#include "gameplay_utils.h"
#include "eeprom_manager.h"

// ── Module state ──────────────────────────────────────────────────────────────
static uint8_t          g_p1_score      = 0;
static uint8_t          g_p2_score      = 0;
static uint8_t          g_led_idx       = 0;
static uint32_t         g_led_time      = 0;
static uint32_t         g_end_ms        = 0;
static ReactionSubState g_sub           = REACTION_COUNTDOWN;
static int8_t           g_round_winner  = 0;
static uint32_t         g_p1_rt         = 0;
static uint32_t         g_p2_rt         = 0;
// Countdown-state init flag – file-scope so reaction_init() can reset it
static bool             g_cd_initialised = false;

void reaction_init(void)
{
    g_p1_score       = 0;
    g_p2_score       = 0;
    g_round_winner   = 0;
    g_p1_rt          = 0;
    g_p2_rt          = 0;
    g_cd_initialised = false;  // force fresh countdown on first round
    g_sub            = REACTION_COUNTDOWN;
}

// ─────────────────────────────────────────────────────────────────────────────
GameState reaction_update(PlayerStats *stats)
{
    if (checkBackToMenu()) { resetGameState(); return STATE_MENU; }

    switch (g_sub)
    {
    // ── COUNTDOWN: random pre-delay, both players must not press anything ─────
    case REACTION_COUNTDOWN:
    {
        // First time entering this state: pick delay and LED
        if (!g_cd_initialised) {
            g_led_idx      = rng_range(4);
            uint32_t delay = rng_range32(REACTION_MIN_DELAY_MS, REACTION_MAX_DELAY_MS);
            g_end_ms       = timer_millis() + delay;
            led_all_off();

            char buf[17];
            snprintf(buf, sizeof(buf), "P1:%u   P2:%u", g_p1_score, g_p2_score);
            display_print(0, buf);
            display_print(1, "Wait for LED...");
            g_cd_initialised = true;
        }

        // Poll for false start while waiting
        uint8_t p1 = p1_buttons_read();
        uint8_t p2 = p2_buttons_read();

        if (p1) {
            // P1 false start → P2 gets point
            g_cd_initialised = false;
            led_all_off();
            failAnimation();
            display_print(0, "P1 FALSE START!");
            display_print(1, "P2 gets point");
            g_p2_score++;
            g_round_winner = 2;
            timer_delay_ms(800);
            g_sub = REACTION_ROUND_RESULT;
            return STATE_REACTION;
        }
        if (p2) {
            // P2 false start → P1 gets point
            g_cd_initialised = false;
            led_all_off();
            failAnimation();
            display_print(0, "P2 FALSE START!");
            display_print(1, "P1 gets point");
            g_p1_score++;
            g_round_winner = 1;
            timer_delay_ms(800);
            g_sub = REACTION_ROUND_RESULT;
            return STATE_REACTION;
        }

        // Pre-delay elapsed → light LED, enter RACE
        if (timer_millis() >= g_end_ms) {
            g_cd_initialised = false;
            led_set(g_led_idx, HIGH);
            g_led_time = timer_millis();
            g_p1_rt    = 0;
            g_p2_rt    = 0;

            char buf[17];
            snprintf(buf, sizeof(buf), "P1:%u   P2:%u", g_p1_score, g_p2_score);
            display_print(0, buf);
            display_print(1, "GO!             ");
            debounce_flush();
            g_sub = REACTION_RACE;
        }
        break;
    }

    // ── RACE: both players react simultaneously ───────────────────────────────
    case REACTION_RACE:
    {
        uint8_t p1 = p1_buttons_read();
        uint8_t p2 = p2_buttons_read();

        bool p1_hit = (p1 & (1u << g_led_idx)) != 0;
        bool p2_hit = (p2 & (1u << g_led_idx)) != 0;

        // Wrong-button press on either side counts as a false start
        bool p1_wrong = p1 && !p1_hit;
        bool p2_wrong = p2 && !p2_hit;

        if (p1_wrong) { p1_hit = false; p1 = 0; g_p2_score++; g_round_winner = 2;
                         led_all_off(); failAnimation();
                         display_print(0, "P1 WRONG BTN!");
                         display_print(1, "P2 gets point");
                         timer_delay_ms(700);
                         g_sub = REACTION_ROUND_RESULT; break; }
        if (p2_wrong) { p2_hit = false; p2 = 0; g_p1_score++; g_round_winner = 1;
                         led_all_off(); failAnimation();
                         display_print(0, "P2 WRONG BTN!");
                         display_print(1, "P1 gets point");
                         timer_delay_ms(700);
                         g_sub = REACTION_ROUND_RESULT; break; }

        if (p1_hit && !g_p1_rt) g_p1_rt = timer_millis() - g_led_time;
        if (p2_hit && !g_p2_rt) g_p2_rt = timer_millis() - g_led_time;

        // Determine winner as soon as at least one player reacted,
        // or after REACTION_TIMEOUT_MS
        bool timeout = (timer_millis() - g_led_time) > REACTION_TIMEOUT_MS;

        if (g_p1_rt || g_p2_rt || timeout) {
            led_all_off();

            if (timeout && !g_p1_rt && !g_p2_rt) {
                // Nobody reacted – no point awarded, replay round
                g_cd_initialised = false;
                display_print(0, "Nobody reacted!");
                display_print(1, "Replay round");
                timer_delay_ms(700);
                g_sub = REACTION_COUNTDOWN;
                break;
            }

            // Pick winner: fastest valid reaction
            if (g_p1_rt && g_p2_rt) {
                g_round_winner = (g_p1_rt <= g_p2_rt) ? 1 : 2;
            } else if (g_p1_rt) {
                g_round_winner = 1;
            } else {
                g_round_winner = 2;
            }

            if (g_round_winner == 1) g_p1_score++;
            else                     g_p2_score++;

            // Show reaction times
            char buf0[17], buf1[17];
            if (g_p1_rt && g_p2_rt) {
                snprintf(buf0, sizeof(buf0), "P1:%lums P2:%lums", g_p1_rt, g_p2_rt);
                snprintf(buf1, sizeof(buf1), "P%u faster! +1", g_round_winner);
            } else if (g_p1_rt) {
                snprintf(buf0, sizeof(buf0), "P1: %lu ms", g_p1_rt);
                snprintf(buf1, sizeof(buf1), "P1 gets point!");
            } else {
                snprintf(buf0, sizeof(buf0), "P2: %lu ms", g_p2_rt);
                snprintf(buf1, sizeof(buf1), "P2 gets point!");
            }
            audio_correct();
            display_print(0, buf0);
            display_print(1, buf1);
            timer_delay_ms(900);
            g_sub = REACTION_ROUND_RESULT;
        }
        break;
    }

    // ── ROUND RESULT ──────────────────────────────────────────────────────────
    case REACTION_ROUND_RESULT:
    {
        char buf[17];
        snprintf(buf, sizeof(buf), "P1:%u   P2:%u", g_p1_score, g_p2_score);
        display_print(0, buf);
        display_print(1, "Next round...");
        if (delay_or_back(600)) { resetGameState(); return STATE_MENU; }

        sleep_reset_timer();

        if (g_p1_score >= WIN_SCORE || g_p2_score >= WIN_SCORE)
            g_sub = REACTION_GAME_OVER;
        else {
            g_cd_initialised = false;
            g_sub = REACTION_COUNTDOWN;
        }
        break;
    }

    // ── GAME OVER ─────────────────────────────────────────────────────────────
    case REACTION_GAME_OVER:
    {
        uint8_t winner = (g_p1_score > g_p2_score) ? 1u : 2u;
        if (winner == 1) stats->p1_wins++; else stats->p2_wins++;
        stats->total_games++;
        eeprom_save(stats);

        winAnimation(winner);
        timer_delay_ms(400);

        wait_all_released();
        display_print2("Reaction done!", "Press any btn");
        while (!any_button_pressed()) {
            if (checkBackToMenu()) { resetGameState(); return STATE_MENU; }
        }
        wait_all_released();
        resetGameState();
        return STATE_MENU;
    }
    }

    return STATE_REACTION;
}