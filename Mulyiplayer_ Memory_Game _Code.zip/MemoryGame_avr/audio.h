#ifndef AUDIO_H
#define AUDIO_H
 
#include <Arduino.h>
#include "config.h"
 
void audio_init(void);
 
void audio_startup(void);       // ascending startup beeps
void audio_menu_click(void);    // short navigation beep
void audio_correct(void);       // correct-input beep
void audio_win(void);           // rapid win melody
void audio_fail(void);          // descending fail tone
 
#endif // AUDIO_H