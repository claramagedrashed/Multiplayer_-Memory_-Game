#ifndef MENU_H
#define MENU_H

#include <Arduino.h>
#include "states.h"

// Initialise menu selection/index and mark UI for initial draw.
void menu_init(void);

// Run one iteration of the menu FSM.
// Returns the GameState the menu transitions to (STATE_MENU if still in menu).
GameState menu_update(void);

// Force redraw (call after returning from a game or wake-up).
void menu_redraw(void);

#endif // MENU_H
