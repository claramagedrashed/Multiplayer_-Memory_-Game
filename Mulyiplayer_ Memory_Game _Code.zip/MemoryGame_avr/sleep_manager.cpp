#include "sleep_manager.h"
#include "timer.h"
#include "display.h"
#include "gpio.h"
#include "audio.h"
#include <avr/sleep.h>
#include <avr/interrupt.h>

static uint32_t g_last_activity = 0;
static bool     g_in_sleep      = false;

// ── Pin-change interrupts: all button banks wake the MCU ─────────────────────
static void pcint_enable(void)
{
    // PCMSK0: D8-D13 (PB0-PB5) — P1 buttons + P2_B3 + buzzer
    PCMSK0 = (1 << PCINT0) | (1 << PCINT1) | (1 << PCINT2) |
             (1 << PCINT3) | (1 << PCINT4) | (1 << PCINT5);
    PCICR |= (1 << PCIE0);

    // PCMSK1: A0-A3 (PC0-PC3) — menu buttons + P2_B4
    PCMSK1 = (1 << PCINT8) | (1 << PCINT9) | (1 << PCINT10) | (1 << PCINT11);
    PCICR |= (1 << PCIE1);

    // PCMSK2: D6 (PD6), D7 (PD7) — P2_B1, P2_B2
    PCMSK2 = (1 << PCINT22) | (1 << PCINT23);
    PCICR |= (1 << PCIE2);
}

static void pcint_disable(void)
{
    PCICR  &= ~((1 << PCIE0) | (1 << PCIE1) | (1 << PCIE2));
    PCMSK0  = 0;
    PCMSK1  = 0;
    PCMSK2  = 0;
}

ISR(PCINT0_vect) {}
ISR(PCINT1_vect) {}
ISR(PCINT2_vect) {}

// ── Public API ────────────────────────────────────────────────────────────────
void sleep_reset_timer(void)
{
    g_last_activity = timer_millis();
    g_in_sleep      = false;
}

void sleep_enter(void)
{
    // Turn off LCD backlight to save power and signal sleep visually
    display_backlight(false);
    display_print2("Press Any Button", "");

    pcint_enable();
    set_sleep_mode(SLEEP_MODE_PWR_DOWN);
    sleep_enable();
    sei();
    sleep_cpu();
    // ── woke up ──────────────────────────────────────────────────────────────
    sleep_disable();
    pcint_disable();

    // Restore LCD immediately after wake
    display_backlight(true);

    // Reset state so we don't immediately re-enter sleep
    g_in_sleep = false;
    g_last_activity = timer_millis();

    // Wait for the waking button to be released before continuing
    wait_all_released();
}

bool sleep_manager_update(void)
{
    if (g_in_sleep) return false;

    uint32_t elapsed = timer_millis() - g_last_activity;
    if (elapsed < SLEEP_INACTIVITY_MS) return false;

    // ── Countdown warning ─────────────────────────────────────────────────────
    display_print(0, "Entering Sleep");
    audio_menu_click();

    for (int8_t i = SLEEP_COUNTDOWN_SEC; i >= 1; i--) {
        display_countdown((uint8_t)i);

        // Poll every 10 ms during each 1-second tick for instant cancel
        uint32_t tick_start = timer_millis();
        while ((timer_millis() - tick_start) < 1000UL) {
            if (any_button_pressed()) {
                wait_all_released();
                sleep_reset_timer();
                display_print2("> Select Mode", "");  // restore menu look
                return false;
            }
        }
    }

    // Countdown complete – enter sleep
    g_in_sleep = true;
    sleep_enter();

    // After wake: signal caller to redraw menu
    return true;
}