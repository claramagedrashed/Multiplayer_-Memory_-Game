#include "menu.h"
#include "display.h"
#include "gpio.h"
#include "audio.h"
#include "sleep_manager.h"

static const char * const MENU_LABELS[MENU_COUNT] = {
    "Solo",
    "Duo",
    "Reaction",
    "Challenger",
    "Stats",
    "Reset EEPROM"
};

static MenuItem g_current    = MENU_SOLO;
static bool     g_needs_draw = true;

static void draw_menu(void)
{
    display_print(0, "> Select Mode");
    display_print(1, MENU_LABELS[g_current]);
    g_needs_draw = false;
}

void menu_init(void)
{
    g_current    = MENU_SOLO;
    g_needs_draw = true;
}

void menu_redraw(void)
{
    g_needs_draw = true;
}

GameState menu_update(void)
{
    if (g_needs_draw) draw_menu();

    if (btn_menu_pressed()) {
        sleep_reset_timer();
        g_current    = (MenuItem)((g_current + 1u) % (uint8_t)MENU_COUNT);
        g_needs_draw = true;
        audio_menu_click();
        wait_all_released();
        return STATE_MENU;
    }

    if (btn_select_pressed()) {
        sleep_reset_timer();
        audio_menu_click();
        wait_all_released();
        switch (g_current) {
            case MENU_SOLO:         return STATE_SOLO;
            case MENU_DUO:          return STATE_DUO;
            case MENU_REACTION:     return STATE_REACTION;
            case MENU_CHALLENGER:   return STATE_CHALLENGER;
            case MENU_STATS:        return STATE_STATS;
            case MENU_RESET_EEPROM: return STATE_RESET_EEPROM;
            default:                return STATE_MENU;
        }
    }

    return STATE_MENU;
}