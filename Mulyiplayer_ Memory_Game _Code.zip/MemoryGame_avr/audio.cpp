/*
 * audio.cpp
 *
 * Buzzer driver — uses Arduino tone()/noTone() which internally manages
 * Timer2.  We do NOT redefine ISR(TIMER2_COMPA_vect) here because
 * Arduino's Tone.cpp already owns that vector; a second definition causes
 * a "multiple definition of __vector_7" linker error.
 *
 * All other I/O (LEDs, buttons) uses direct AVR registers in gpio.cpp.
 */

#include "audio.h"
#include "timer.h"
#include <avr/io.h>

static void beep(uint16_t freq, uint16_t dur_ms)
{
    tone(BUZZER_PIN, freq, dur_ms);
    timer_delay_ms(dur_ms);
    noTone(BUZZER_PIN);
    timer_delay_ms(5);
}

void audio_init(void)
{
    // D12 = PB4: output, start LOW
    DDRB  |=  (1<<PB4);
    PORTB &= ~(1<<PB4);
}

void audio_startup(void)
{
    beep(440,  60);
    beep(550,  60);
    beep(660,  60);
    beep(880, 100);
}

void audio_menu_click(void) { beep(800,  20); }
void audio_correct(void)    { beep(1000, 35); }

void audio_win(void)
{
    static const uint16_t f[] = {523, 659, 784, 1047};
    for (uint8_t i = 0; i < 4; i++) beep(f[i], 60);
    beep(1047, 140);
}

void audio_fail(void)
{
    beep(400, 70);
    beep(300, 70);
    beep(200, 140);
}
