/*
 * timer.cpp — AVR Timer1 CTC, 1 ms tick @ 16 MHz
 *
 * OCR1A = (F_CPU / (prescaler * 1000)) - 1
 *       = (16 000 000 / (8 * 1000)) - 1 = 1999
 */

#include "timer.h"
#include <avr/io.h>
#include <avr/interrupt.h>

static volatile uint32_t g_ticks = 0;

void timer_init(void)
{
    cli();

    TCCR1A = 0;
    TCCR1B = 0;
    TCNT1  = 0;

    OCR1A  = 1999;                    // 1 ms at 16 MHz / 8
    TCCR1B = (1 << WGM12)            // CTC mode
           | (1 << CS11);            // prescaler /8
    TIMSK1 = (1 << OCIE1A);          // enable compare-A interrupt

    sei();
}

ISR(TIMER1_COMPA_vect)
{
    g_ticks++;
}

uint32_t timer_millis(void)
{
    uint32_t t;
    cli();
    t = g_ticks;
    sei();
    return t;
}

void timer_delay_ms(uint32_t ms)
{
    uint32_t start = timer_millis();
    while ((timer_millis() - start) < ms) {}
}
