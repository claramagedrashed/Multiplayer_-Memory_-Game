#ifndef EEPROM_MANAGER_H
#define EEPROM_MANAGER_H

#include <Arduino.h>

// Persisted statistics layout in EEPROM.
// Keep checksum as the last field (validation code depends on that ordering).
typedef struct {
    uint16_t p1_wins;
    uint16_t p2_wins;
    uint16_t best_solo_score;
    uint16_t total_games;
    uint8_t  checksum;
} PlayerStats;

// Verify compile-time assumptions (struct size/layout safety checks).
void     eeprom_init(void);
// Read stats from EEPROM and auto-reset if checksum is invalid.
void     eeprom_load(PlayerStats *stats);
// Save stats with a recalculated checksum.
void     eeprom_save(const PlayerStats *stats);
// Zero all stats and persist defaults immediately.
void     eeprom_reset(PlayerStats *stats);

#endif // EEPROM_MANAGER_H
