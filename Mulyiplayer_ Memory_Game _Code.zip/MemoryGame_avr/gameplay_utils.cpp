#include "gameplay_utils.h"
#include "gpio.h"
#include "audio.h"
#include "display.h"
#include "timer.h"
#include "config.h"
#include <avr/io.h>

// Silence the buzzer (Arduino tone() owns Timer2, so use noTone())
static inline void buzzer_off(void)
{
    noTone(BUZZER_PIN);
    PORTB &= ~(1<<PB4);   // pull D12 low via AVR register
}

// ── Back-button exit ───────────────────────────────────────────────────────────
bool checkBackToMenu(void)
{
    if (back_pressed_raw()) {
        led_all_off();
        buzzer_off();
        wait_all_released();
        return true;
    }
    return false;
}

// ── Hardware cleanup ───────────────────────────────────────────────────────────
void resetGameState(void)
{
    led_all_off();
    buzzer_off();
}

// ── Failure animation ──────────────────────────────────────────────────────────
void failAnimation(void)
{
    audio_fail();
    for (uint8_t i = 0; i < 2; i++) {
        led_all_on();
        timer_delay_ms(120);
        led_all_off();
        timer_delay_ms(100);
    }
}

// ── Victory animation ──────────────────────────────────────────────────────────
void winAnimation(uint8_t player)
{
    char line[17];
    snprintf(line, sizeof(line), "PLAYER %u WINS!", player);
    display_print2(line, "");

    static const uint16_t FREQS[4] = {523, 659, 784, 1047};
    for (uint8_t i = 0; i < 8; i++) {
        if (i & 1u) {
            led_set(0, HIGH); led_set(2, HIGH);
            led_set(1, LOW);  led_set(3, LOW);
        } else {
            led_set(1, HIGH); led_set(3, HIGH);
            led_set(0, LOW);  led_set(2, LOW);
        }
        tone(BUZZER_PIN, FREQS[i & 3u], 75);
        timer_delay_ms(85);
    }
    led_all_off();
    tone(BUZZER_PIN, 1047, 380);
    timer_delay_ms(400);
    noTone(BUZZER_PIN);
}

// ── Interruptible delay ────────────────────────────────────────────────────────
bool delay_or_back(uint32_t ms)
{
    uint32_t start = timer_millis();
    while ((timer_millis() - start) < ms) {
        if (back_pressed_raw()) {
            led_all_off();
            buzzer_off();
            wait_all_released();
            return true;
        }
    }
    return false;
}
