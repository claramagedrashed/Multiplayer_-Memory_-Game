#ifndef GPIO_H
#define GPIO_H

#include <Arduino.h>
#include "config.h"

void gpio_init(void);

// ─── LED control (AVR direct register) ────────────────────────────────────────
void led_set(uint8_t ledIndex, uint8_t state);  // ledIndex 0-3
void led_all_off(void);
void led_all_on(void);

// ─── Debounce flush ────────────────────────────────────────────────────────────
// Reset all debounce timestamps so the very next press is accepted.
// MUST be called before every new player input phase (each new sequence round).
void debounce_flush(void);

// ─── Debounced button reads ────────────────────────────────────────────────────
uint8_t p1_buttons_read(void);   // bits 0-3 = buttons 0-3
uint8_t p2_buttons_read(void);

bool btn_menu_pressed(void);
bool btn_select_pressed(void);
bool btn_back_pressed(void);

// ─── Raw reads (no debounce) ───────────────────────────────────────────────────
bool back_pressed_raw(void);     // instant BACK check inside gameplay loops
bool any_button_pressed(void);   // sleep wake / "press any key" waits

void wait_all_released(void);

#endif // GPIO_H
