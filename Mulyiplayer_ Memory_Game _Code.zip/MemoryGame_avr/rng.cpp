#include "rng.h"
#include "config.h"
#include "timer.h"

void rng_init(void)
{
    // Seed from floating ADC pin noise.
    // Mix with an LCG between reads to decorrelate successive samples
    // and avoid the shift-overflow issue when i*4 >= 32.
    uint32_t seed = 0;
    for (uint8_t i = 0; i < 16; i++) {
        seed = seed * 1664525UL + 1013904223UL;   // LCG mix
        seed ^= (uint32_t)analogRead(A5);
        timer_delay_ms(1);                          // let ADC settle + add time jitter
    }
    randomSeed(seed ? seed : 42UL);
}

uint8_t rng_range(uint8_t max_exclusive)
{
    if (max_exclusive == 0) return 0;
    return (uint8_t)(random(max_exclusive));
}

uint8_t rng_next_led(uint8_t last_led)
{
    uint8_t next;
    do {
        next = rng_range(4);
    } while (next == last_led);
    return next;
}

uint32_t rng_range32(uint32_t lo, uint32_t hi)
{
    if (hi <= lo) return lo;
    uint32_t range = hi - lo;           // no +1 overflow risk
    if (range == 0xFFFFFFFFUL) range--; // edge-case guard
    return lo + (uint32_t)(random((long)(range + 1UL)));
}
