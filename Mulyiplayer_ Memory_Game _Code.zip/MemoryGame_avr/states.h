#ifndef STATES_H
#define STATES_H

typedef enum {
    // Main menu / idle navigation state.
    STATE_MENU = 0,
    // Single-player memory challenge.
    STATE_SOLO,
    // Two-player sequence replay competition.
    STATE_DUO,
    // Simultaneous reaction speed duel.
    STATE_REACTION,
    // One player creates sequence, other repeats from memory.
    STATE_CHALLENGER,
    // View persisted stats.
    STATE_STATS,
    // Confirm + execute EEPROM stats reset.
    STATE_RESET_EEPROM,
    // Explicit sleep state entry (optional path).
    STATE_SLEEP
} GameState;

typedef enum {
    SOLO_SHOWING_SEQUENCE = 0,
    SOLO_WAITING_INPUT,
    SOLO_SUCCESS,
    SOLO_FAIL
} SoloSubState;

typedef enum {
    DUO_SHOWING_SEQUENCE = 0,  // show random LED sequence to both players
    DUO_P1_INPUT,               // P1 reproduces the sequence
    DUO_P2_INPUT,               // P2 reproduces the sequence
    DUO_COMPARE,                // compare both results, award points
    DUO_ROUND_RESULT,           // brief pause / score display
    DUO_GAME_OVER
} DuoSubState;

// Reaction – simultaneous
typedef enum {
    REACTION_COUNTDOWN = 0,
    REACTION_RACE,
    REACTION_ROUND_RESULT,
    REACTION_GAME_OVER
} ReactionSubState;

typedef enum {
    CHALLENGER_A_ENTERING = 0,
    CHALLENGER_HANDOFF,
    CHALLENGER_SHOW_TO_B,
    CHALLENGER_B_REPEATING,
    CHALLENGER_ROUND_RESULT,
    CHALLENGER_GAME_OVER
} ChallengerSubState;

typedef enum {
    MENU_SOLO = 0,
    MENU_DUO,
    MENU_REACTION,
    MENU_CHALLENGER,
    MENU_STATS,
    MENU_RESET_EEPROM,
    MENU_COUNT
} MenuItem;

#endif // STATES_H