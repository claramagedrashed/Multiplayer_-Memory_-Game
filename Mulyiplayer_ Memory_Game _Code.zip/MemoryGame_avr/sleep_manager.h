#ifndef SLEEP_MANAGER_H
#define SLEEP_MANAGER_H

#include <Arduino.h>
#include "config.h"

// Reset menu inactivity tracking.
// Call this whenever a user performs an action (menu navigation/selection).
// This prevents accidental sleep while the user is actively playing/navigating.
void sleep_reset_timer(void);

// Run one step of sleep management while in STATE_MENU.
// Behavior:
// 1) If inactivity threshold not reached -> returns false immediately.
// 2) If reached -> shows countdown and allows cancel by any key press.
// 3) If countdown completes -> enters low-power sleep and wakes on button IRQ.
// Returns true only after a complete sleep->wake cycle so caller can redraw UI.
bool sleep_manager_update(void);

// Enter AVR power-down sleep right now.
// The function blocks until any configured button wakes the MCU, then
// restores display state and waits for button release before returning.
void sleep_enter(void);

#endif // SLEEP_MANAGER_H