#include "eeprom_manager.h"
#include <EEPROM.h>
#include <string.h>

#define EEPROM_BASE_ADDR  0

static uint8_t calc_checksum(const PlayerStats *s)
{
    uint8_t cs = 0;
    const uint8_t *p = (const uint8_t *)s;
    // checksum over everything except the checksum byte itself
    for (uint8_t i = 0; i < (sizeof(PlayerStats) - 1); i++) {
        cs ^= p[i];
    }
    return cs;
}

void eeprom_init(void)
{
    // Verify struct layout has no unexpected padding that would
    // shift the checksum byte away from the last position.
    // If this fails to compile, a field was added without updating this check.
    static_assert(sizeof(PlayerStats) == 9,
        "PlayerStats layout changed — verify checksum byte is still last and coverage is correct");
}

void eeprom_load(PlayerStats *stats)
{
    EEPROM.get(EEPROM_BASE_ADDR, *stats);
    if (stats->checksum != calc_checksum(stats)) {
        // Corrupt or first boot – reset to defaults
        eeprom_reset(stats);
    }
}

void eeprom_save(const PlayerStats *stats)
{
    PlayerStats tmp;
    memcpy(&tmp, stats, sizeof(PlayerStats));
    tmp.checksum = calc_checksum(&tmp);
    EEPROM.put(EEPROM_BASE_ADDR, tmp);
}

void eeprom_reset(PlayerStats *stats)
{
    memset(stats, 0, sizeof(PlayerStats));
    eeprom_save(stats);
}
