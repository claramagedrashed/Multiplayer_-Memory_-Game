#include "solo.h"
#include "display.h"
#include "gpio.h"
#include "audio.h"
#include "timer.h"
#include "rng.h"
#include "sleep_manager.h"
#include "gameplay_utils.h"
#include "eeprom_manager.h"

static uint8_t      g_sequence[MAX_SEQUENCE];
static uint8_t      g_seq_len    = 0;
static uint8_t      g_input_idx  = 0;
static uint16_t     g_display_ms = SOLO_INIT_DISPLAY_MS;
static SoloSubState g_sub        = SOLO_SHOWING_SEQUENCE;

// Show the full sequence; returns false if BACK pressed mid-display
static bool show_sequence(void)
{
    for (uint8_t i = 0; i < g_seq_len; i++) {
        if (checkBackToMenu()) return false;
        led_all_off();
        timer_delay_ms(80);
        led_set(g_sequence[i], HIGH);
        if (delay_or_back((uint32_t)g_display_ms)) return false;
        led_all_off();
        timer_delay_ms(60);
    }
    return true;
}

void solo_init(void)
{
    g_seq_len    = 0;
    g_input_idx  = 0;
    g_display_ms = SOLO_INIT_DISPLAY_MS;
    g_sub        = SOLO_SHOWING_SEQUENCE;
    g_sequence[0] = rng_range(4);
    g_seq_len     = 1;
}

GameState solo_update(PlayerStats *stats)
{
    if (checkBackToMenu()) { resetGameState(); return STATE_MENU; }

    switch (g_sub)
    {
    // ── SHOW SEQUENCE ─────────────────────────────────────────────────────────
    case SOLO_SHOWING_SEQUENCE:
    {
        display_solo_score((uint16_t)(g_seq_len - 1u));
        display_print(1, "Watch...");
        if (delay_or_back(250)) { resetGameState(); return STATE_MENU; }

        if (!show_sequence()) { resetGameState(); return STATE_MENU; }

        g_input_idx = 0;
        display_solo_score((uint16_t)(g_seq_len - 1u));
        display_print(1, "Your turn!");
        sleep_reset_timer();

        // ── THE FIX ──────────────────────────────────────────────────────────
        // Flush debounce timestamps so the first button press of this new
        // input phase is never rejected due to a stale timestamp from the
        // previous round's last press or wait_all_released() settle time.
        debounce_flush();

        g_sub = SOLO_WAITING_INPUT;
        break;
    }

    // ── WAIT FOR INPUT ────────────────────────────────────────────────────────
    case SOLO_WAITING_INPUT:
    {
        uint32_t t_start   = timer_millis();
        bool     timed_out = false;

        while (g_input_idx < g_seq_len) {
            if (checkBackToMenu()) { resetGameState(); return STATE_MENU; }

            if ((timer_millis() - t_start) > SOLO_TIMEOUT_MS) {
                timed_out = true;
                break;
            }

            uint8_t pressed = p1_buttons_read();
            if (!pressed) continue;

            sleep_reset_timer();

            uint8_t btn = 0xFF;
            for (uint8_t b = 0; b < 4; b++)
                if (pressed & (1u << b)) { btn = b; break; }
            if (btn == 0xFF) continue;

            // Visual echo
            led_set(btn, HIGH);
            timer_delay_ms(100);
            led_set(btn, LOW);

            // Require full release to prevent a held press being counted twice
            // (which can auto-fail the next expected step in longer rounds).
            wait_all_released();
            debounce_flush();

            if (btn == g_sequence[g_input_idx]) {
                audio_correct();
                g_input_idx++;
                t_start = timer_millis();
            } else {
                g_sub = SOLO_FAIL;
                wait_all_released();
                return STATE_SOLO;
            }
        }

        g_sub = timed_out ? SOLO_FAIL : SOLO_SUCCESS;
        break;
    }

    // ── SUCCESS ───────────────────────────────────────────────────────────────
    case SOLO_SUCCESS:
    {
        audio_correct();
        display_solo_score(g_seq_len);
        display_print(1, "Correct!");
        if (delay_or_back(400)) { resetGameState(); return STATE_MENU; }

        if (g_seq_len < MAX_SEQUENCE) {
            g_sequence[g_seq_len] = rng_next_led(g_sequence[g_seq_len - 1]);
            g_seq_len++;
        }

        if (g_display_ms > (uint16_t)(SOLO_MIN_SPEED_MS + SOLO_SPEED_STEP_MS))
            g_display_ms -= SOLO_SPEED_STEP_MS;
        else
            g_display_ms = SOLO_MIN_SPEED_MS;

        g_sub = SOLO_SHOWING_SEQUENCE;
        break;
    }

    // ── FAIL ──────────────────────────────────────────────────────────────────
    case SOLO_FAIL:
    {
        uint16_t score = (g_seq_len > 1u) ? (uint16_t)(g_seq_len - 1u) : 0u;

        failAnimation();

        char buf[17];
        snprintf(buf, sizeof(buf), "Score: %u", score);
        display_print(0, "Game Over!");
        display_print(1, buf);

        if (score > stats->best_solo_score)
            stats->best_solo_score = score;
        stats->total_games++;
        eeprom_save(stats);

        timer_delay_ms(400);
        wait_all_released();
        debounce_flush();

        display_print(1, "Press any btn");
        while (!any_button_pressed()) {
            if (checkBackToMenu()) { resetGameState(); return STATE_MENU; }
        }
        wait_all_released();
        resetGameState();
        return STATE_MENU;
    }
    }

    return STATE_SOLO;
}
