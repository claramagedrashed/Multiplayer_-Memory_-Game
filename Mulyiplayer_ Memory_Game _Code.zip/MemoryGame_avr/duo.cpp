#include "duo.h"
#include "display.h"
#include "gpio.h"
#include "audio.h"
#include "timer.h"
#include "rng.h"
#include "sleep_manager.h"
#include "gameplay_utils.h"
#include "eeprom_manager.h"

static uint8_t     g_sequence[MAX_SEQUENCE];
static uint8_t     g_seq_len   = 0;
static uint8_t     g_p1_score  = 0;
static uint8_t     g_p2_score  = 0;
static bool        g_p1_correct = false;
static bool        g_p2_correct = false;
static DuoSubState g_sub       = DUO_SHOWING_SEQUENCE;
static uint16_t    g_disp_ms   = SOLO_INIT_DISPLAY_MS;

static bool show_sequence(void)
{
    for (uint8_t i = 0; i < g_seq_len; i++) {
        if (checkBackToMenu()) return false;
        led_all_off();
        if (delay_or_back(30))         return false;
        led_set(g_sequence[i], HIGH);
        if (delay_or_back(g_disp_ms))  return false;
        led_all_off();
        if (delay_or_back(30))         return false;
    }
    return true;
}

static bool player_any_raw(bool is_p1)
{
    if (is_p1) {
        return (digitalRead(P1_B1_PIN) == LOW ||
                digitalRead(P1_B2_PIN) == LOW ||
                digitalRead(P1_B3_PIN) == LOW ||
                digitalRead(P1_B4_PIN) == LOW);
    }
    return (digitalRead(P2_B1_PIN) == LOW ||
            digitalRead(P2_B2_PIN) == LOW ||
            digitalRead(P2_B3_PIN) == LOW ||
            digitalRead(P2_B4_PIN) == LOW);
}

// player_input — reads buttons for one player, expects them to reproduce
// g_sequence in order.  Returns true on full success, false on error/timeout.
static bool player_input(bool is_p1)
{
    uint8_t  idx     = 0;
    uint32_t t_start = timer_millis();

    // ── THE FIX ──────────────────────────────────────────────────────────────
    // Flush debounce so the first button press of this phase is never
    // rejected by a stale timestamp from the previous sequence display.
    debounce_flush();

    while (idx < g_seq_len) {
        if (btn_back_pressed()) {
            wait_all_released();
            return false;
        }

        if ((timer_millis() - t_start) > SOLO_TIMEOUT_MS) {
            audio_fail();
            return false;
        }

        uint8_t pressed = is_p1 ? p1_buttons_read() : p2_buttons_read();
        if (pressed == 0) continue;

        sleep_reset_timer();

        uint8_t btn = 0xFF;
        for (uint8_t b = 0; b < 4; b++)
            if (pressed & (1u << b)) { btn = b; break; }
        if (btn == 0xFF) continue;

        // Visual + audio echo
        led_set(btn, HIGH);
        audio_correct();
        timer_delay_ms(80);
        led_set(btn, LOW);

        // Flush after feedback so next button isn't gated by this timestamp
        debounce_flush();

        // Wait for full release before accepting next press.
        while (player_any_raw(is_p1)) {}
        timer_delay_ms(20);

        if (btn == g_sequence[idx]) {
            idx++;
            t_start = timer_millis();
        } else {
            audio_fail();
            return false;
        }
    }

    return true;
}

void duo_init(void)
{
    g_seq_len    = 1;
    g_p1_score   = 0;
    g_p2_score   = 0;
    g_p1_correct = false;
    g_p2_correct = false;
    g_disp_ms    = SOLO_INIT_DISPLAY_MS;
    g_sub        = DUO_SHOWING_SEQUENCE;
    g_sequence[0] = rng_range(4);
}

GameState duo_update(PlayerStats *stats)
{
    if (checkBackToMenu()) { resetGameState(); return STATE_MENU; }

    switch (g_sub)
    {
    case DUO_SHOWING_SEQUENCE:
    {
        display_scores(g_p1_score, g_p2_score);
        display_print(1, "Watch...");
        if (delay_or_back(200))      { resetGameState(); return STATE_MENU; }
        if (!show_sequence())        { resetGameState(); return STATE_MENU; }

        display_scores(g_p1_score, g_p2_score);
        display_print(1, "P1 Turn");
        if (delay_or_back(120))      { resetGameState(); return STATE_MENU; }

        g_sub = DUO_P1_INPUT;
        break;
    }

    case DUO_P1_INPUT:
    {
        g_p1_correct = player_input(true);

        if (btn_back_pressed()) {
            wait_all_released();
            resetGameState();
            return STATE_MENU;
        }

        display_print(1, g_p1_correct ? "P1 Correct!" : "P1 Failed!");
        if (!g_p1_correct) failAnimation();
        if (delay_or_back(250))      { resetGameState(); return STATE_MENU; }

        display_scores(g_p1_score, g_p2_score);
        display_print(1, "P2 Turn");
        if (delay_or_back(120))      { resetGameState(); return STATE_MENU; }

        g_sub = DUO_P2_INPUT;
        break;
    }

    case DUO_P2_INPUT:
    {
        g_p2_correct = player_input(false);

        if (btn_back_pressed()) {
            wait_all_released();
            resetGameState();
            return STATE_MENU;
        }

        display_print(1, g_p2_correct ? "P2 Correct!" : "P2 Failed!");
        if (!g_p2_correct) failAnimation();
        if (delay_or_back(250))      { resetGameState(); return STATE_MENU; }

        g_sub = DUO_COMPARE;
        break;
    }

    case DUO_COMPARE:
    {
        if (g_p1_correct && g_p2_correct) {
            g_p1_score++;
            g_p2_score++;
            display_print2("Both Correct!", "Both +1");
            audio_correct();
        } else if (g_p1_correct) {
            g_p1_score++;
            display_print2("P1 Wins Round", "P1 +1");
        } else if (g_p2_correct) {
            g_p2_score++;
            display_print2("P2 Wins Round", "P2 +1");
        } else {
            display_print2("Both Failed!", "No Points");
        }

        if (delay_or_back(500))      { resetGameState(); return STATE_MENU; }
        g_sub = DUO_ROUND_RESULT;
        break;
    }

    case DUO_ROUND_RESULT:
    {
        display_scores(g_p1_score, g_p2_score);
        display_print(1, "Next Round...");
        if (delay_or_back(400))      { resetGameState(); return STATE_MENU; }

        bool p1_wins = (g_p1_score >= WIN_SCORE);
        bool p2_wins = (g_p2_score >= WIN_SCORE);

        if ((p1_wins || p2_wins) && (g_p1_score != g_p2_score)) {
            g_sub = DUO_GAME_OVER;
        } else {
            if (g_seq_len < MAX_SEQUENCE) {
                g_sequence[g_seq_len] = rng_next_led(g_sequence[g_seq_len - 1]);
                g_seq_len++;
            }
            if (g_disp_ms > SOLO_MIN_SPEED_MS)
                g_disp_ms -= SOLO_SPEED_STEP_MS;
            g_sub = DUO_SHOWING_SEQUENCE;
        }
        break;
    }

    case DUO_GAME_OVER:
    {
        if (g_p1_score > g_p2_score) { stats->p1_wins++; winAnimation(1); }
        else                          { stats->p2_wins++; winAnimation(2); }
        stats->total_games++;
        eeprom_save(stats);

        if (delay_or_back(1500)) { resetGameState(); return STATE_MENU; }
        resetGameState();
        return STATE_MENU;
    }
    }

    return STATE_DUO;
}
