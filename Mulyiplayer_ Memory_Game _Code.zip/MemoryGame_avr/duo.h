#ifndef DUO_H
#define DUO_H

#include <Arduino.h>
#include "states.h"
#include "eeprom_manager.h"

void duo_init(void);
GameState duo_update(PlayerStats *stats);

#endif // DUO_H
