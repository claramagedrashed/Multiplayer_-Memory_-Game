#ifndef DISPLAY_H
#define DISPLAY_H

#include <Arduino.h>
#include "config.h"

// Initialize I2C LCD, enable backlight, and clear screen.
void display_init(void);
// Clear both LCD rows.
void display_clear(void);
// Control LCD backlight power.
void display_backlight(bool on);

// Print text to a specific row (0/1), auto pad/truncate to LCD width.
void display_print(uint8_t row, const char *text);
// Convenience helper to print both rows in one call.
void display_print2(const char *row0, const char *row1);
// printf-style formatted write to one row.
void display_printf(uint8_t row, const char *fmt, ...);

// Print "P1:.. P2:.." score format on row 0.
void display_scores(uint8_t p1, uint8_t p2);
// Print solo score line on row 0.
void display_solo_score(uint16_t score);
// Print countdown value on row 1.
void display_countdown(uint8_t n);

#endif // DISPLAY_H