/*
 * gpio.cpp — AVR direct-register I/O
 *
 * Pin mapping (Arduino Uno / ATmega328P):
 *
 *  LEDs       D2-D5   → PORTD bits 2-5   (OUTPUT)
 *  P1 buttons D8-D11  → PORTB bits 0-3   (INPUT_PULLUP, active LOW)
 *  Buzzer     D12     → PORTB bit 4      (OUTPUT)
 *  P2_B1      D6      → PORTD bit 6      (INPUT_PULLUP, active LOW)
 *  P2_B2      D7      → PORTD bit 7      (INPUT_PULLUP, active LOW)
 *  P2_B3      D13     → PORTB bit 5      (INPUT_PULLUP, active LOW)
 *  P2_B4      A3      → PORTC bit 3      (INPUT_PULLUP, active LOW)
 *  MENU_BTN   A0      → PORTC bit 0      (INPUT_PULLUP, active LOW)
 *  SELECT_BTN A1      → PORTC bit 1      (INPUT_PULLUP, active LOW)
 *  BACK_BTN   A2      → PORTC bit 2      (INPUT_PULLUP, active LOW)
 *
 * KEY FIX: debounce_flush() resets all timestamps to 0 so the very
 * next press is accepted.  Call it before every new input phase.
 */

#include "gpio.h"
#include "timer.h"
#include <avr/io.h>

// ─── Debounce state ────────────────────────────────────────────────────────────
static uint32_t g_last_p1[4]   = {0,0,0,0};
static uint32_t g_last_p2[4]   = {0,0,0,0};
static uint32_t g_last_menu[3] = {0,0,0};

// ─── Low-level pin read (AVR register, no Arduino overhead) ───────────────────
static inline bool pin_is_low(uint8_t arduino_pin)
{
    switch (arduino_pin)
    {
        case 2:  return !(PIND & (1<<PD2));
        case 3:  return !(PIND & (1<<PD3));
        case 4:  return !(PIND & (1<<PD4));
        case 5:  return !(PIND & (1<<PD5));
        case 6:  return !(PIND & (1<<PD6));
        case 7:  return !(PIND & (1<<PD7));
        case 8:  return !(PINB & (1<<PB0));
        case 9:  return !(PINB & (1<<PB1));
        case 10: return !(PINB & (1<<PB2));
        case 11: return !(PINB & (1<<PB3));
        case 12: return !(PINB & (1<<PB4));
        case 13: return !(PINB & (1<<PB5));
        case A0: return !(PINC & (1<<PC0));
        case A1: return !(PINC & (1<<PC1));
        case A2: return !(PINC & (1<<PC2));
        case A3: return !(PINC & (1<<PC3));
        default: return false;
    }
}

// Debounced read: returns true once per press after DEBOUNCE_MS quiet time
static bool debounce_pin(uint8_t pin, uint32_t *last_time)
{
    if (pin_is_low(pin)) {
        uint32_t now = timer_millis();
        if ((now - *last_time) > DEBOUNCE_MS) {
            *last_time = now;
            return true;
        }
    }
    return false;
}

// ─── gpio_init ─────────────────────────────────────────────────────────────────
void gpio_init(void)
{
    // LEDs D2-D5 (PD2-PD5): outputs, start LOW
    DDRD  |=  (1<<PD2)|(1<<PD3)|(1<<PD4)|(1<<PD5);
    PORTD &= ~((1<<PD2)|(1<<PD3)|(1<<PD4)|(1<<PD5));

    // P1 buttons D8-D11 (PB0-PB3): inputs, pull-ups ON
    DDRB  &= ~((1<<PB0)|(1<<PB1)|(1<<PB2)|(1<<PB3));
    PORTB |=  (1<<PB0)|(1<<PB1)|(1<<PB2)|(1<<PB3);

    // Buzzer D12 (PB4): output, start LOW
    DDRB  |=  (1<<PB4);
    PORTB &= ~(1<<PB4);

    // P2_B3 D13 (PB5): input, pull-up ON
    DDRB  &= ~(1<<PB5);
    PORTB |=  (1<<PB5);

    // P2_B1 D6 (PD6), P2_B2 D7 (PD7): inputs, pull-ups ON
    DDRD  &= ~((1<<PD6)|(1<<PD7));
    PORTD |=  (1<<PD6)|(1<<PD7);

    // P2_B4 A3 (PC3), MENU A0 (PC0), SELECT A1 (PC1), BACK A2 (PC2): inputs, pull-ups ON
    DDRC  &= ~((1<<PC0)|(1<<PC1)|(1<<PC2)|(1<<PC3));
    PORTC |=  (1<<PC0)|(1<<PC1)|(1<<PC2)|(1<<PC3);
}

// ─── LED control (AVR direct) ──────────────────────────────────────────────────
// LED 0=PD2, 1=PD3, 2=PD4, 3=PD5
void led_set(uint8_t idx, uint8_t state)
{
    if (idx >= 4) return;
    uint8_t bit = (uint8_t)(1u << (idx + 2u));
    if (state) PORTD |=  bit;
    else        PORTD &= ~bit;
}

void led_all_off(void)
{
    PORTD &= ~((1<<PD2)|(1<<PD3)|(1<<PD4)|(1<<PD5));
}

void led_all_on(void)
{
    PORTD |= (1<<PD2)|(1<<PD3)|(1<<PD4)|(1<<PD5);
}

// ─── Debounce flush ────────────────────────────────────────────────────────────
// THE FIX: Call before every new input phase so the first button press
// on sequence 2, 3, … is never silently blocked by a stale timestamp.
void debounce_flush(void)
{
    for (uint8_t i = 0; i < 4; i++) {
        g_last_p1[i] = 0;
        g_last_p2[i] = 0;
    }
    g_last_menu[0] = 0;
    g_last_menu[1] = 0;
    g_last_menu[2] = 0;
}

// ─── Button reads (debounced) ──────────────────────────────────────────────────
uint8_t p1_buttons_read(void)
{
    uint8_t mask = 0;
    static const uint8_t P1[4] = { P1_B1_PIN, P1_B2_PIN, P1_B3_PIN, P1_B4_PIN };
    for (uint8_t i = 0; i < 4; i++)
        if (debounce_pin(P1[i], &g_last_p1[i])) mask |= (1u << i);
    return mask;
}

uint8_t p2_buttons_read(void)
{
    uint8_t mask = 0;
    static const uint8_t P2[4] = { P2_B1_PIN, P2_B2_PIN, P2_B3_PIN, P2_B4_PIN };
    for (uint8_t i = 0; i < 4; i++)
        if (debounce_pin(P2[i], &g_last_p2[i])) mask |= (1u << i);
    return mask;
}

bool btn_menu_pressed(void)   { return debounce_pin(MENU_BTN_PIN,   &g_last_menu[0]); }
bool btn_select_pressed(void) { return debounce_pin(SELECT_BTN_PIN, &g_last_menu[1]); }
bool btn_back_pressed(void)   { return debounce_pin(BACK_BTN_PIN,   &g_last_menu[2]); }

// Raw BACK — no debounce, minimum latency exit from gameplay loops
bool back_pressed_raw(void)
{
    return pin_is_low(BACK_BTN_PIN);   // A2 = PC2
}

// Raw any-button — no debounce; used for sleep wake / "press any key" waits
bool any_button_pressed(void)
{
    // P1 buttons: PB0-PB3
    if (!(PINB & (1<<PB0))) return true;
    if (!(PINB & (1<<PB1))) return true;
    if (!(PINB & (1<<PB2))) return true;
    if (!(PINB & (1<<PB3))) return true;
    // P2_B1 D6=PD6, P2_B2 D7=PD7
    if (!(PIND & (1<<PD6))) return true;
    if (!(PIND & (1<<PD7))) return true;
    // P2_B3 D13=PB5
    if (!(PINB & (1<<PB5))) return true;
    // P2_B4 A3=PC3
    if (!(PINC & (1<<PC3))) return true;
    // Menu/Select/Back: PC0, PC1, PC2
    if (!(PINC & (1<<PC0))) return true;
    if (!(PINC & (1<<PC1))) return true;
    if (!(PINC & (1<<PC2))) return true;
    return false;
}

void wait_all_released(void)
{
    while (any_button_pressed()) {}
    timer_delay_ms(40);   // absorb contact bounce on release
}
