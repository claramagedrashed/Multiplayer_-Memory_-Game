#ifndef RNG_H
#define RNG_H

#include <Arduino.h>

// Seed Arduino PRNG from ADC noise and timing jitter.
void rng_init(void);

// Return a random number in [0, max)
uint8_t rng_range(uint8_t max_exclusive);

// Generate next LED index avoiding same as last
uint8_t rng_next_led(uint8_t last_led);

// Return random uint32 in [lo, hi] (inclusive bounds).
uint32_t rng_range32(uint32_t lo, uint32_t hi);

#endif // RNG_H
